﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        Pen p = new Pen(Color.Black, 5);

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        public int lvl = 1;
        public string[] slovo = { "азбука", "бюджет", "балдёж" };
        public string lvl_slovo = null;
        public int shag = 0;

        private void button1_Click(object sender, EventArgs e)
        {
            groupBox1.Visible = false;
            groupBox2.Visible = true;
            button2.Visible = true;
            textBox1.Text = ""; textBox2.Text = ""; textBox3.Text = ""; textBox4.Text = ""; textBox5.Text = "";
            textBox6.Text = ""; textBox7.Text = "";
            textBox2.Visible = false; textBox3.Visible = false; 
            textBox4.Visible = false; textBox5.Visible = false; textBox6.Visible = false; 
            textBox7.Visible = false;
            textBox1.MaxLength = 1;
            MessageBox.Show("Поставть расскладку клавиатуры на русский язык.\n" +
                "Вводить только буквы.\n" +
                "Введённый символ будет считаться как ошибка выбора буквы");

            if (radioButton1.Checked) // изи (Азбука)
            {
                label1.Text = "В чудесном домике живут. Веселые друзья, их всех по имени зовут От буквы А до Я. \n" +
                    "И ты, коль с ними не знаком, стучись быстрее в дружный дом!";
                label2.Text = "Использованные буквы:";
                lvl = 1;
                lvl_slovo = slovo[lvl - 1];
                textBox2.Text = lvl_slovo[0].ToString();
                textBox3.Text = lvl_slovo[1].ToString();
                textBox4.Text = lvl_slovo[2].ToString();
                textBox5.Text = lvl_slovo[3].ToString();
                textBox6.Text = lvl_slovo[4].ToString();
                textBox7.Text = lvl_slovo[5].ToString();

            } else if (radioButton2.Checked) // нормал (Бюджет)
            {
                label1.Text = "Роспись доходов и расходов государства, учреждения, семьи или отдельного лица на определенный срок";
                label2.Text = "Использованные буквы:";
                lvl = 2;
                lvl_slovo = slovo[lvl - 1];
                textBox2.Text = lvl_slovo[0].ToString();
                textBox3.Text = lvl_slovo[1].ToString();
                textBox4.Text = lvl_slovo[2].ToString();
                textBox5.Text = lvl_slovo[3].ToString();
                textBox6.Text = lvl_slovo[4].ToString();
                textBox7.Text = lvl_slovo[5].ToString();
            }
            else // сверхразум (Балдёж)
            {
                label1.Text = "Пустое и бессмысленное времяпрепровождение.";
                label2.Text = "Использованные буквы:";
                lvl = 3;
                lvl_slovo = slovo[lvl - 1];
                textBox2.Text = lvl_slovo[0].ToString();
                textBox3.Text = lvl_slovo[1].ToString();
                textBox4.Text = lvl_slovo[2].ToString();
                textBox5.Text = lvl_slovo[3].ToString();
                textBox6.Text = lvl_slovo[4].ToString();
                textBox7.Text = lvl_slovo[5].ToString();
            }
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsDigit(e.KeyChar)) return;
            else e.Handled = true;
        }

        private void textBox1_KeyDown(object sender, KeyEventArgs e)
        {
            Graphics gr = this.CreateGraphics();

            if (shag > 10)
            {
                MessageBox.Show("Ты проиграл...");
                gr.Clear(Color.White);
                button2.PerformClick();
            }

            if (e.KeyData == Keys.Enter && textBox1.Text != "")
            {
                if (lvl == 1) //Азбука
                {
                    if (label4.Text.IndexOf(textBox1.Text) == -1)
                    {
                        label4.Text.Trim();
                        switch (textBox1.Text)
                        {
                            case "А": case "а": textBox2.Visible = true; label4.Text += textBox1.Text + " "; textBox7.Visible = true; textBox1.Text = null; break;
                            case "З": case "з": textBox3.Visible = true; label4.Text += textBox1.Text + " "; textBox1.Text = null; break;
                            case "Б": case "б": textBox4.Visible = true; label4.Text += textBox1.Text + " "; textBox1.Text = null; break;
                            case "У": case "у": textBox5.Visible = true; label4.Text += textBox1.Text + " "; textBox1.Text = null; break;
                            case "К": case "к": textBox6.Visible = true; label4.Text += textBox1.Text + " "; textBox1.Text = null; break;
                            default:
                                label4.Text += textBox1.Text + " "; textBox1.Text = null; shag++;
                                //Прорисовка элемента
                                switch (shag)
                                {
                                    case 1: gr.DrawLine(p, 150, 10, 150, 250); break;  // |
                                    case 2: gr.DrawLine(p, 140, 250, 240, 250); break; // _
                                    case 3: gr.DrawLine(p, 140, 10, 280, 10); break;   // -
                                    case 4: gr.DrawLine(p, 150, 40, 190, 10); break;   // /
                                    case 5: gr.DrawLine(p, 260, 10, 260, 40); break;   // '
                                    case 6: gr.DrawEllipse(p, 240, 40, 40, 40); break; // o
                                    case 7: gr.DrawEllipse(p, 230, 80, 60, 80); break; // 0
                                    case 8: gr.DrawLine(p, 250, 80, 200, 120); break; // /0
                                    case 9: gr.DrawLine(p, 270, 80, 320, 120); break; // 0\
                                    case 10: gr.DrawLine(p, 245, 155, 220, 220); break; // /0
                                    case 11: gr.DrawLine(p, 275, 155, 300, 220); break; // 
                                }
                                break;
                        }

                    }
                    else MessageBox.Show("Эта буква уже вводилась");
                }
                else if(lvl == 2) // Бюджет
                {
                    if (label4.Text.IndexOf(textBox1.Text) == -1)
                    {
                        label4.Text.Trim();
                        switch (textBox1.Text)
                        {
                            case "Б": case "б": textBox2.Visible = true; label4.Text += textBox1.Text + " "; textBox1.Text = null; break;
                            case "Ю": case "ю": textBox3.Visible = true; label4.Text += textBox1.Text + " "; textBox1.Text = null; break;
                            case "Д": case "д": textBox4.Visible = true; label4.Text += textBox1.Text + " "; textBox1.Text = null; break;
                            case "Ж": case "ж": textBox5.Visible = true; label4.Text += textBox1.Text + " "; textBox1.Text = null; break;
                            case "Е": case "е": textBox6.Visible = true; label4.Text += textBox1.Text + " "; textBox1.Text = null; break;
                            case "Т": case "т": textBox7.Visible = true; label4.Text += textBox1.Text + " "; textBox1.Text = null; break;
                            default:
                                label4.Text += textBox1.Text + " "; textBox1.Text = null; shag++;
                                //Прорисовка элемента
                                switch (shag)
                                {
                                    case 1: gr.DrawLine(p, 150, 10, 150, 250); break;  // |
                                    case 2: gr.DrawLine(p, 140, 250, 240, 250); break; // _
                                    case 3: gr.DrawLine(p, 140, 10, 280, 10); break;   // -
                                    case 4: gr.DrawLine(p, 150, 40, 190, 10); break;   // /
                                    case 5: gr.DrawLine(p, 260, 10, 260, 40); break;   // '
                                    case 6: gr.DrawEllipse(p, 240, 40, 40, 40); break; // o
                                    case 7: gr.DrawEllipse(p, 230, 80, 60, 80); break; // 0
                                    case 8: gr.DrawLine(p, 250, 80, 200, 120); break; // /0
                                    case 9: gr.DrawLine(p, 270, 80, 320, 120); break; // 0\
                                    case 10: gr.DrawLine(p, 245, 155, 220, 220); break; // /0
                                    case 11: gr.DrawLine(p, 275, 155, 300, 220); break; // 
                                }
                                break;
                        }
                    }
                    else MessageBox.Show("Эта буква уже вводилась");
                }
                else if(lvl == 3)
                {
                    if (label4.Text.IndexOf(textBox1.Text) == -1)
                    {
                        label4.Text.Trim();
                        switch (textBox1.Text)
                        {
                            case "Б": case "б": textBox2.Visible = true; label4.Text += textBox1.Text + " "; textBox1.Text = null; break;
                            case "А": case "а": textBox3.Visible = true; label4.Text += textBox1.Text + " "; textBox1.Text = null; break;
                            case "Л": case "л": textBox4.Visible = true; label4.Text += textBox1.Text + " "; textBox1.Text = null; break;
                            case "Д": case "д": textBox5.Visible = true; label4.Text += textBox1.Text + " "; textBox1.Text = null; break;
                            case "Ё": case "ё": textBox6.Visible = true; label4.Text += textBox1.Text + " "; textBox1.Text = null; break;
                            case "Ж": case "ж": textBox7.Visible = true; label4.Text += textBox1.Text + " "; textBox1.Text = null; break;
                            default:
                                label4.Text += textBox1.Text + " "; textBox1.Text = null; shag++;
                                //Прорисовка элемента
                                switch (shag)
                                {
                                    case 1: gr.DrawLine(p, 150, 10, 150, 250); break;  // |
                                    case 2: gr.DrawLine(p, 140, 250, 240, 250); break; // _
                                    case 3: gr.DrawLine(p, 140, 10, 280, 10); break;   // -
                                    case 4: gr.DrawLine(p, 150, 40, 190, 10); break;   // /
                                    case 5: gr.DrawLine(p, 260, 10, 260, 40); break;   // '
                                    case 6: gr.DrawEllipse(p, 240, 40, 40, 40); break; // o
                                    case 7: gr.DrawEllipse(p, 230, 80, 60, 80); break; // 0
                                    case 8: gr.DrawLine(p, 250, 80, 200, 120); break; // /0
                                    case 9: gr.DrawLine(p, 270, 80, 320, 120); break; // 0\
                                    case 10: gr.DrawLine(p, 245, 155, 220, 220); break; // /0
                                    case 11: gr.DrawLine(p, 275, 155, 300, 220); break; // 
                                }
                                break;
                        }
                    }
                    else MessageBox.Show("Эта буква уже вводилась");
                }

                if (textBox2.Visible && textBox3.Visible && textBox4.Visible && textBox5.Visible && textBox6.Visible && textBox7.Visible)
                {
                    MessageBox.Show("Молодец! Ты победил");
                    groupBox2.Visible = false;
                    groupBox1.Visible = true;
                    button2.Visible = false;
                    textBox2.Visible = false; textBox3.Visible = false; textBox4.Visible = false;
                    textBox5.Visible = false; textBox6.Visible = false; textBox7.Visible = false;
                    shag = 0;
                    gr.Clear(Color.White);
                    label4.Text = "";
                }

            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            groupBox2.Visible = false;
            groupBox1.Visible = true;
            button2.Visible = false;
            shag = 0;
            label4.Text = "";
            this.CreateGraphics().Clear(Color.White);
        }


    }
}
